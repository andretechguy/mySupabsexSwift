//
//  UserManagementApp.swift
//  UserManagement
//
//  Created by Guilherme Souza on 17/11/23.
//

import SwiftUI

@main
struct UserManagementApp: App {
  var body: some Scene {
    WindowGroup {
      AppView()
    }
  }
}
