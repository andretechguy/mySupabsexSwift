#!/bin/bash

cp _Secrets.swift Secrets.swift